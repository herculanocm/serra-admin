package br.com.cunha.controller;

import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.view.Results;
import br.com.cunha.interfaces.RepoFuncionarioI;
import br.com.cunha.modelo.Funcionario;



@Controller
public class FuncionariosController {

	private static final Logger logger = LoggerFactory.getLogger(FuncionariosController.class);
	
	private RepoFuncionarioI repoFuncionarioI;
	private Validator validator;
	private Result result;

	
	
	protected FuncionariosController() {
	}
	
	
	
	@Inject
	public FuncionariosController(RepoFuncionarioI repoFuncionarioI, Result result, Validator validator){
		this.repoFuncionarioI=repoFuncionarioI;
		this.result = result;
		this.validator=validator;
	}
	
	@Path("/funcionarios/index")
	public void index() {
		result.include("variable", "VRaptor!");
	}
	
	
	@Get @Path("/funcionarios")
	public void lista(){
		logger.info("Listando Funcionarios - metodo get");
		/*
		Funcionario f = new Funcionario();
		f.setId(new Long(1));
		f.setNome("herculano");
		f.setMatricula("448383");
		*/
		List<Funcionario> listaFuncionario= repoFuncionarioI.todosFuncionarios();
		result.use(Results.json()).from(listaFuncionario).serialize();
	}
	
	@Post @Path("/funcionario")
	public void salva(Funcionario funcionario){
		logger.info("Sanvando novo Funcionario - metodo post, dados toString: "+funcionario.toString());
		
		
		
		Set<ConstraintViolation<Funcionario>> constranintViolation = validator.validate(funcionario);
		
		logger.info("constranintViolation: "+constranintViolation.iterator().next().getMessage());
		
		
	
		
	}
	
	
}
