package br.com.cunha.modelo;

import java.math.BigInteger;
import java.util.List;

public class Pessoa {
	
	private BigInteger id;
	private String nome;
	private String fantasia;
	private BigInteger cgc;

	private List<Endereco> enderecos;
	private List<Fone> fone;
	

}
