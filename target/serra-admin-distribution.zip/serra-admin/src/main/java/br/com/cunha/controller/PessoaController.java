package br.com.cunha.controller;

import br.com.caelum.vraptor.Controller;

@Controller
public class PessoaController {

}
