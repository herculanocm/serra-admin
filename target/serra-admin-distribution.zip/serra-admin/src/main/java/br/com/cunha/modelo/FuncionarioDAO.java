package br.com.cunha.modelo;

import java.util.List;

public class FuncionarioDAO implements FuncionarioDAOI {

	@Override
	public void addFuncionario(Funcionario funcionario) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Funcionario> allFuncionarios() {
		// TODO Auto-generated method stub
		return null;
	}

}
