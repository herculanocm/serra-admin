package br.com.cunha.repositorios;

import java.util.List;

import br.com.cunha.interfaces.RepoPessoaI;
import br.com.cunha.modelo.Pessoa;

public class RepoPessoa implements RepoPessoaI{

	@Override
	public void salvarPessoa(Pessoa pessoa) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Pessoa> listarPessoas() {
		// TODO Auto-generated method stub
		return null;
	}

}
