package br.com.cunha.modelo;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.joda.time.LocalDate;

public class HistoricoSalariosFuncionario {
	
	private BigInteger idPessoa;
	private LocalDate dtInclusao;
	private BigDecimal salarioAtual;
	private String descricao;
	private String justificativa;
	private String usuarioInclusao;
	
	

}
